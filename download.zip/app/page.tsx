
"use client";

import { useState, useEffect } from 'react';
import SosButton from '@/components/SosButton';
import LocationMap from '@/components/LocationMap';
import InitialWelcomeScreen from '@/components/InitialWelcomeScreen';
import GenderForm from '@/components/GenderForm';
import UserNameForm from '@/components/UserNameForm';
import PhoneNumberForm from '@/components/PhoneNumberForm';
import EmergencyContactsForm, { type EmergencyContact } from '@/components/EmergencyContactsForm';
import SafeWordForm from '@/components/SafeWordForm';
import SelfDefenseModal from '@/components/SelfDefenseModal';
import TransportationOptionsModal from '@/components/TransportationOptionsModal';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Siren, ShieldHalf, PhoneCall, ShieldAlert, CarFront, UserCheck, Car, KeyRound } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

type AppStep = 'loading' | 'initialWelcome' | 'genderSelection' | 'userName' | 'phoneNumber' | 'emergencyContacts' | 'safeWordSetup' | 'mainApp';

export default function HomePage() {
  const [appStep, setAppStep] = useState<AppStep>('loading');
  const [sosActive, setSosActive] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);
  const [_userGender, setUserGender] = useState<string | null>(null);
  const [_initialSafeWord, setInitialSafeWord] = useState<string | null>(null);
  const [showSelfDefenseModal, setShowSelfDefenseModal] = useState(false);
  const [showTransportationModal, setShowTransportationModal] = useState(false);
  const { toast } = useToast();
  const [currentOtp, setCurrentOtp] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
        if (appStep === 'loading') {
            setAppStep('initialWelcome');
        }
    }, 500); 
    return () => clearTimeout(timer);
  }, [appStep]);


  const handleInitialWelcomeProceed = () => {
    setAppStep('genderSelection');
  };

  const handleGenderSubmit = (gender: string) => {
    console.log("User gender selected:", gender);
    setUserGender(gender);
    toast({
      title: "Gender Selected",
      description: `You've selected ${gender}. Let's get your name next.`,
      duration: 4000,
    });
    setAppStep('userName');
  };

  const handleUserNameSubmit = (name: string) => {
    console.log("User name saved (simulated):", name);
    setUserName(name);
    toast({
      title: "Name Saved",
      description: `Welcome, ${name}! Let's proceed to the next step.`,
      duration: 4000,
    });
    setAppStep('phoneNumber');
  };

  const handlePhoneNumberSubmit = (phoneNumber: string) => {
    console.log("Phone number saved (simulated):", phoneNumber);
    setAppStep('emergencyContacts'); 
  };

  const handleEmergencyContactsSubmit = (contacts: EmergencyContact[]) => {
    console.log("Emergency contacts saved (simulated):", contacts);
    toast({
      title: "Emergency Contacts Saved",
      description: "Your emergency contacts have been successfully set up. Next, set your voice alert safe word.",
      duration: 5000,
    });
    setAppStep('safeWordSetup');
  };

  const handleSafeWordSubmit = (safeWord: string) => {
    console.log("Safe word set (simulated):", safeWord);
    setInitialSafeWord(safeWord);
    toast({
      title: "Safe Word Set",
      description: "Your voice alert safe word has been configured. Welcome to ZEKO!",
      duration: 5000,
    });
    setAppStep('mainApp');
  };

  const handleSosActivate = () => {
    setSosActive(true);
    toast({
      title: "SOS Activated!",
      description: "Emergency contacts will be notified and your location shared.",
      variant: "destructive",
      duration: 7000, 
    });
  };

  const handleSosDeactivate = () => {
    setSosActive(false);
    toast({
      title: "SOS Deactivated",
      description: "You have marked yourself as safe. SOS alerts have been stopped.",
      duration: 5000,
    });
  };

  const handleSelfDefenseClick = () => {
    setShowSelfDefenseModal(true);
  }

  const handleCallEmergencyServices = () => {
    toast({
      title: "Contacting SHE TEAM",
      description: "Simulating call to SHE TEAM...",
      variant: "default",
      duration: 4000,
    });
    setTimeout(() => {
      toast({
        title: "Contacting Police",
        description: "Simulating call to Police...",
        variant: "default",
        duration: 4000,
      });
    }, 1000);
  };

  const handleTransportationClick = () => {
    setShowTransportationModal(true); 
  };

  const generateOtp = () => {
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    setCurrentOtp(otp);
    return otp;
  }

  const handleTransportationOptionSelect = (option: 'auto' | 'car') => {
    const vehicleType = option === 'auto' ? 'Auto Rickshaw' : 'Car';
    toast({
        title: `${vehicleType} Selected`,
        description: `Simulating request for an ${vehicleType.toLowerCase()}.`,
        duration: 3000,
    });
    setShowTransportationModal(false);

    setTimeout(() => {
        const otp = generateOtp();
        const driverName = "Ramesh K.";
        const vehicleModel = option === 'auto' ? "Bajaj RE" : "Suzuki Swift";
        const vehicleNumber = option === 'auto' ? "AP 05 Z 1234" : "TS 09 XY 5678";

        toast({
            title: "Ride Confirmed!",
            description: (
              <div className="space-y-2 text-sm">
                <p>Your {vehicleType.toLowerCase()} is on the way.</p>
                <div className="flex items-center">
                  <UserCheck className="w-4 h-4 mr-2 text-primary" />
                  <span>Driver: {driverName}</span>
                </div>
                <div className="flex items-center">
                  <Car className="w-4 h-4 mr-2 text-primary" />
                  <span>Vehicle: {vehicleModel} ({vehicleNumber})</span>
                </div>
                <div className="flex items-center">
                  <KeyRound className="w-4 h-4 mr-2 text-primary" />
                  <span className="font-semibold">OTP: {otp}</span>
                </div>
              </div>
            ),
            duration: 10000, // Increased duration to allow reading
        });
    }, 3200);
  };


  if (appStep === 'loading') {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4">
            <ShieldAlert className="w-24 h-24 md:w-32 md:h-32 text-primary mb-6 animate-pulse" /> 
            <p className="text-lg text-muted-foreground">Loading ZEKO...</p>
        </div>
    );
  }

  if (appStep === 'initialWelcome') {
    return <InitialWelcomeScreen onProceed={handleInitialWelcomeProceed} />;
  }

  if (appStep === 'genderSelection') {
    return <GenderForm onSubmitGender={handleGenderSubmit} />;
  }

  if (appStep === 'userName') {
    return <UserNameForm onSubmitName={handleUserNameSubmit} />;
  }

  if (appStep === 'phoneNumber') {
    return <PhoneNumberForm onSubmitPhoneNumber={handlePhoneNumberSubmit} />;
  }

  if (appStep === 'emergencyContacts') {
    return <EmergencyContactsForm onSubmitEmergencyContacts={handleEmergencyContactsSubmit} />;
  }

  if (appStep === 'safeWordSetup') {
    return <SafeWordForm onSubmitSafeWord={handleSafeWordSubmit} />;
  }

  // Main app content (appStep === 'mainApp')
  return (
    <div className="flex flex-col items-center min-h-screen bg-background p-4 md:p-8 space-y-8 font-sans">
      <header className="w-full max-w-5xl text-center pt-8">
        <div className="text-center flex-grow">
            <h1 className="text-5xl md:text-6xl font-bold text-primary flex items-center justify-center">
            <ShieldAlert className="w-12 h-12 md:w-16 md:h-16 mr-3" /> 
            ZEKO
            </h1>
            <p className="text-muted-foreground mt-2 text-lg md:text-xl">Your Personal Safety Companion</p>
        </div>
      </header>

      {userName && (
        <p className="text-center text-2xl md:text-3xl font-semibold text-foreground mt-4 mb-2">Hey, {userName}!</p>
      )}
      
      {currentOtp && appStep === 'mainApp' && (
         <Card className="w-full max-w-md shadow-lg rounded-xl border-primary bg-primary/5 my-4">
          <CardHeader>
            <CardTitle className="flex items-center text-primary text-xl">
              <KeyRound className="w-6 h-6 mr-2" />
              Your Ride OTP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-4xl font-bold text-foreground">{currentOtp}</p>
            <p className="text-center text-muted-foreground mt-1 text-sm">Share this OTP with your driver to start the ride.</p>
          </CardContent>
        </Card>
      )}


      <main className="w-full max-w-5xl flex flex-col items-center gap-6 md:gap-8 pb-8">
        <Card className="w-full shadow-xl rounded-xl border border-border">
          <CardHeader>
            <CardTitle className="flex items-center text-primary text-2xl">
              <Siren className="w-7 h-7 mr-2" />
              SOS & Location
            </CardTitle>
            <CardDescription>Immediate help and location tracking.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-6 pt-0">
            <p className="text-center text-muted-foreground px-2 mt-2">
              {sosActive ? "SOS is currently active. Press the button below to mark yourself safe." : "Press SOS to activate emergency alerts and share your location with contacts."}
            </p>
            <SosButton 
              onPress={sosActive ? handleSosDeactivate : handleSosActivate} 
              isActive={sosActive} 
            />
            
            <div className="w-full max-w-md">
              <LocationMap />
            </div>
          </CardContent>
        </Card>

        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          <Card className="shadow-xl rounded-xl border border-border">
            <CardHeader>
              <CardTitle className="flex items-center text-primary text-xl md:text-2xl">
                <ShieldHalf className="w-6 h-6 md:w-7 md:h-7 mr-2" />
                Self Defense
              </CardTitle>
              <CardDescription className="text-sm md:text-base">Access self-defense resources.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center pt-0">
              <Button 
                onClick={handleSelfDefenseClick} 
                variant="outline" 
                size="lg" 
                className="w-full max-w-xs text-base md:text-lg py-4 md:py-6 border-primary text-primary hover:bg-primary/10 mt-4"
              >
                SELF DEFENSE
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-xl rounded-xl border border-border">
            <CardHeader>
              <CardTitle className="flex items-center text-primary text-xl md:text-2xl">
                <PhoneCall className="w-6 h-6 md:w-7 md:h-7 mr-2" />
                Emergency Call
              </CardTitle>
              <CardDescription className="text-sm md:text-base">Contact emergency services.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center pt-0">
              <Button
                onClick={handleCallEmergencyServices}
                variant="destructive"
                size="lg"
                className="w-full max-w-xs text-base md:text-lg py-4 md:py-6 mt-4"
              >
                <PhoneCall className="w-5 h-5 md:w-6 md:h-6 mr-2" />
                CALL
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-xl rounded-xl border border-border">
            <CardHeader>
              <CardTitle className="flex items-center text-primary text-xl md:text-2xl">
                <CarFront className="w-6 h-6 md:w-7 md:h-7 mr-2" />
                Transportation
              </CardTitle>
              <CardDescription className="text-sm md:text-base">Arrange safe transport.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center pt-0">
              <Button
                onClick={handleTransportationClick}
                variant="outline"
                size="lg"
                className="w-full max-w-xs text-base md:text-lg py-4 md:py-6 border-primary text-primary hover:bg-primary/10 mt-4"
              >
                 <CarFront className="w-5 h-5 md:w-6 md:h-6 mr-2" />
                TRANSPORT
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="text-center text-sm text-muted-foreground py-6">
        <p>&copy; {new Date().getFullYear()} ZEKO. All rights reserved.</p>
        <p>Stay Safe. Stay Alert.</p>
      </footer>

      <SelfDefenseModal 
        isOpen={showSelfDefenseModal} 
        onClose={() => setShowSelfDefenseModal(false)} 
      />
      <TransportationOptionsModal
        isOpen={showTransportationModal}
        onClose={() => setShowTransportationModal(false)}
        onSelectOption={handleTransportationOptionSelect}
      />
    </div>
  );
}

